# يشغَّل بعد: npx cap add android
import os
PKG = "com.smsoffline.app"
base = "android/app/src/main"
jdir = f"{base}/java/{PKG.replace('.', '/')}"
os.makedirs(jdir, exist_ok=True)

for f in ("SmsBridgePlugin.java", "DataSmsReceiver.java", "TextSmsReceiver.java"):
    s = open(f"native/{f}", encoding="utf-8").read().replace("__PKG__", PKG)
    open(f"{jdir}/{f}", "w", encoding="utf-8").write(s)

open(f"{jdir}/MainActivity.java", "w", encoding="utf-8").write(f"""package {PKG};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {{
  @Override
  public void onCreate(Bundle b) {{
    registerPlugin(SmsBridgePlugin.class);
    super.onCreate(b);
  }}
}}
""")

mf = f"{base}/AndroidManifest.xml"
x = open(mf, encoding="utf-8").read()
if "DataSmsReceiver" not in x:
    perms = """    <uses-permission android:name="android.permission.SEND_SMS" />
    <uses-permission android:name="android.permission.RECEIVE_SMS" />
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <uses-feature android:name="android.hardware.telephony" android:required="true" />
"""
    recv = """        <receiver android:name=".DataSmsReceiver" android:exported="true"
            android:permission="android.permission.BROADCAST_SMS">
            <intent-filter>
                <action android:name="android.intent.action.DATA_SMS_RECEIVED" />
                <data android:scheme="sms" android:host="localhost" android:port="8901" />
            </intent-filter>
        </receiver>
        <receiver android:name=".TextSmsReceiver" android:exported="true"
            android:permission="android.permission.BROADCAST_SMS">
            <intent-filter>
                <action android:name="android.provider.Telephony.SMS_RECEIVED" />
            </intent-filter>
        </receiver>
"""
    x = x.replace("<application", perms + "    <application", 1)
    x = x.replace("</application>", recv + "    </application>", 1)
    open(mf, "w", encoding="utf-8").write(x)
print("OK: الإضافة جاهزة")
