package __PKG__;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Base64;

public class TextSmsReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context ctx, Intent intent) {
    for (SmsMessage m : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
      String body = m.getMessageBody();
      if (body == null || !body.startsWith("~")) continue;
      try {
        String b64 = body.substring(1).trim();
        byte[] d = Base64.decode(b64, Base64.DEFAULT);
        if (d.length < 3 || (d[0] & 0xFF) != 0xA7) continue;
        SmsBridgePlugin.deliver(ctx, m.getOriginatingAddress(), b64);
      } catch (Exception e) { }
    }
  }
}
