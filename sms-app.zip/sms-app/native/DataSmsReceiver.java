package __PKG__;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Base64;

public class DataSmsReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context ctx, Intent intent) {
    for (SmsMessage m : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
      byte[] d = m.getUserData();
      if (d == null) continue;
      SmsBridgePlugin.deliver(ctx, m.getOriginatingAddress(), Base64.encodeToString(d, Base64.NO_WRAP));
    }
  }
}
