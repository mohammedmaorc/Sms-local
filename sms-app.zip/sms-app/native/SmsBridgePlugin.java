package __PKG__;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import org.json.JSONArray;
import java.util.List;

@CapacitorPlugin(
  name = "SmsBridge",
  permissions = {
    @Permission(alias = "sms", strings = {
      Manifest.permission.SEND_SMS,
      Manifest.permission.RECEIVE_SMS,
      Manifest.permission.READ_PHONE_STATE
    })
  }
)
public class SmsBridgePlugin extends Plugin {
  static SmsBridgePlugin inst;

  @Override
  public void load() { inst = this; }

  private List<SubscriptionInfo> subs() {
    SubscriptionManager sm = (SubscriptionManager) getContext().getSystemService(Context.TELEPHONE_SUBSCRIPTION_SERVICE);
    return sm.getActiveSubscriptionInfoList();
  }

  @PluginMethod
  public void getSims(PluginCall call) {
    if (getPermissionState("sms") != PermissionState.GRANTED) {
      requestPermissionForAlias("sms", call, "simsCb");
      return;
    }
    simsCb(call);
  }

  @PermissionCallback
  private void simsCb(PluginCall call) {
    JSArray arr = new JSArray();
    if (getPermissionState("sms") == PermissionState.GRANTED) {
      List<SubscriptionInfo> l = subs();
      if (l != null) {
        for (SubscriptionInfo i : l) {
          JSObject o = new JSObject();
          o.put("slot", i.getSimSlotIndex());
          o.put("subId", i.getSubscriptionId());
          o.put("carrier", "SIM " + (i.getSimSlotIndex() + 1) + " - " + i.getCarrierName());
          arr.put(o);
        }
      }
    }
    JSObject r = new JSObject();
    r.put("sims", arr);
    call.resolve(r);
  }

  @PluginMethod
  public void sendData(PluginCall call) {
    if (getPermissionState("sms") != PermissionState.GRANTED) {
      call.reject("permission denied");
      return;
    }
    try {
      String to = call.getString("to");
      byte[] data = Base64.decode(call.getString("data"), Base64.DEFAULT);
      int slot = call.getInt("slot", 0);
      int port = call.getInt("port", 8901);
      int subId = SubscriptionManager.getDefaultSmsSubscriptionId();
      List<SubscriptionInfo> l = subs();
      if (l != null) for (SubscriptionInfo i : l) if (i.getSimSlotIndex() == slot) subId = i.getSubscriptionId();
      SmsManager m = SmsManager.getSmsManagerForSubscriptionId(subId);
      m.sendDataMessage(to, null, (short) port, data, null, null);
      call.resolve();
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void sendText(PluginCall call) {
    if (getPermissionState("sms") != PermissionState.GRANTED) {
      call.reject("permission denied");
      return;
    }
    try {
      String to = call.getString("to");
      String text = call.getString("text");
      int slot = call.getInt("slot", 0);
      int subId = SubscriptionManager.getDefaultSmsSubscriptionId();
      List<SubscriptionInfo> l = subs();
      if (l != null) for (SubscriptionInfo i : l) if (i.getSimSlotIndex() == slot) subId = i.getSubscriptionId();
      SmsManager m = SmsManager.getSmsManagerForSubscriptionId(subId);
      m.sendTextMessage(to, null, text, null, null);
      call.resolve();
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void getPending(PluginCall call) {
    SharedPreferences sp = getContext().getSharedPreferences("sms_pending", Context.MODE_PRIVATE);
    JSObject r = new JSObject();
    try { r.put("items", new JSArray(sp.getString("q", "[]"))); }
    catch (Exception e) { r.put("items", new JSArray()); }
    sp.edit().clear().apply();
    call.resolve(r);
  }

  static void deliver(Context ctx, String from, String data) {
    JSObject o = new JSObject();
    o.put("from", from);
    o.put("data", data);
    if (inst != null) { inst.notifyListeners("dataSms", o, true); return; }
    SharedPreferences sp = ctx.getSharedPreferences("sms_pending", Context.MODE_PRIVATE);
    try {
      JSONArray a = new JSONArray(sp.getString("q", "[]"));
      a.put(o);
      sp.edit().putString("q", a.toString()).apply();
    } catch (Exception e) { }
  }
}
